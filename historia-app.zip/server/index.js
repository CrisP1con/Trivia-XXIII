import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import path from 'path';
import { fileURLToPath } from 'url';
import db from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3001;
const SECRET_KEY = "super_secreto_para_la_escuela";

app.use(helmet({
  crossOriginResourcePolicy: false,
}));
app.use(cors());
app.use(express.json());
app.use('/videos', express.static(path.join(__dirname, '../public/videos')));

function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) return res.sendStatus(401);

  jwt.verify(token, SECRET_KEY, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  
  db.get("SELECT * FROM users WHERE username = ?", [username], async (err, user) => {
    if (err) return res.status(500).json({ error: "Error de servidor" });
    if (!user) return res.status(401).json({ error: "Credenciales inválidas" });
    
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.status(401).json({ error: "Credenciales inválidas" });
    
    const token = jwt.sign({ id: user.id, username: user.username }, SECRET_KEY, { expiresIn: '24h' });
    res.json({ token });
  });
});

app.get('/api/game-data', (req, res) => {
  db.all("SELECT * FROM stations ORDER BY `order` ASC", [], (err, stations) => {
    if (err) return res.status(500).json({ error: err.message });
    
    db.all("SELECT * FROM questions", [], (err, allQuestions) => {
      if (err) return res.status(500).json({ error: err.message });
      
      const formattedStations = stations.map(station => {
        const stationQuestions = allQuestions.filter(q => q.station_id === station.id);
        return {
          id: station.id,
          title: station.title,
          video: station.video,
          bridge: station.bridge,
          questions: stationQuestions.map(q => ({
            id: q.id,
            prompt: q.prompt,
            options: JSON.parse(q.options),
            answer: q.answer,
            explanation: q.explanation
          }))
        };
      });
      
      res.json({
        title: "Instituto Juan XXIII",
        subtitle: "60 años educando con historia y futuro",
        stations: formattedStations
      });
    });
  });
});

app.get('/api/stations', (req, res) => {
  db.all("SELECT * FROM stations ORDER BY `order` ASC", [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// CRUD Stations
app.post('/api/stations', (req, res) => {
  const { title, video, bridge, order } = req.body;
  db.run(`INSERT INTO stations (title, video, bridge, "order") VALUES (?, ?, ?, ?)`, 
    [title, video, bridge, order], function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID, title, video, bridge, order });
  });
});

app.put('/api/stations/:id', (req, res) => {
  const { title, video, bridge, order } = req.body;
  db.run(`UPDATE stations SET title = ?, video = ?, bridge = ?, "order" = ? WHERE id = ?`, 
    [title, video, bridge, order, req.params.id], function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ success: true });
  });
});

app.delete('/api/stations/:id', (req, res) => {
  db.run(`DELETE FROM questions WHERE station_id = ?`, [req.params.id], (err) => {
    db.run(`DELETE FROM stations WHERE id = ?`, [req.params.id], function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ success: true });
    });
  });
});

// CRUD Questions
app.get('/api/questions', (req, res) => {
  db.all("SELECT * FROM questions", [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    const parsedRows = rows.map(r => ({ ...r, options: JSON.parse(r.options || '[]') }));
    res.json(parsedRows);
  });
});

app.post('/api/questions', (req, res) => {
  const { station_id, prompt, options, answer, explanation } = req.body;
  db.run(`INSERT INTO questions (station_id, prompt, options, answer, explanation) VALUES (?, ?, ?, ?, ?)`, 
    [station_id, prompt, JSON.stringify(options), answer, explanation], function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID });
  });
});

app.put('/api/questions/:id', (req, res) => {
  const { station_id, prompt, options, answer, explanation } = req.body;
  db.run(`UPDATE questions SET station_id = ?, prompt = ?, options = ?, answer = ?, explanation = ? WHERE id = ?`, 
    [station_id, prompt, JSON.stringify(options), answer, explanation, req.params.id], function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ success: true });
  });
});

app.delete('/api/questions/:id', (req, res) => {
  db.run(`DELETE FROM questions WHERE id = ?`, [req.params.id], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true });
  });
});

app.listen(PORT, () => {
  console.log(`Backend funcionando en http://localhost:${PORT}`);
});
