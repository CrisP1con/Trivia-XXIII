import sqlite3Pkg from 'sqlite3';
const sqlite3 = sqlite3Pkg.verbose();
import path from 'path';
import bcrypt from 'bcrypt';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dbPath = path.resolve(__dirname, 'database.sqlite');

const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Error al conectar con SQLite:', err.message);
  } else {
    console.log('Conectado a la base de datos SQLite.');
    initDb();
  }
});

function initDb() {
  db.serialize(() => {
    // Tabla de usuarios (Admin)
    db.run(`CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE,
      password TEXT
    )`);

    // Tabla de épocas / estaciones
    db.run(`CREATE TABLE IF NOT EXISTS stations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT,
      video TEXT,
      bridge TEXT,
      "order" INTEGER
    )`);

    // Tabla de preguntas
    db.run(`CREATE TABLE IF NOT EXISTS questions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      station_id INTEGER,
      prompt TEXT,
      options TEXT, -- Guardado como JSON string ["A", "B"]
      answer INTEGER,
      explanation TEXT,
      FOREIGN KEY (station_id) REFERENCES stations (id)
    )`);

    // Crear un usuario admin por defecto si no existe
    db.get("SELECT id FROM users WHERE username = 'admin'", async (err, row) => {
      if (!row) {
        const hash = await bcrypt.hash('123456', 10);
        db.run("INSERT INTO users (username, password) VALUES ('admin', ?)", [hash]);
        console.log("Usuario por defecto creado: admin / 123456");
      }
    });
  });
}

export default db;
