import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { 
  LayoutDashboard, BookOpen, HelpCircle, 
  Bell, Database, Server,
  PlayCircle, Layers
} from "lucide-react";
import GameView from "./game/GameView";
import MateriasManager from "./admin/MateriasManager";
import PreguntasManager from "./admin/PreguntasManager";
import "./admin.css";

function AdminLogin() {
  return (
    <div style={{ display: "flex", height: "100vh", alignItems: "center", justifyContent: "center", backgroundColor: "#171821", color: "white", flexDirection: "column" }}>
      <img src="/logo.png" alt="Logo" style={{ height: "120px", marginBottom: "24px" }} />
      <h1>Panel de Administración</h1>
      <p style={{ color: "#A0A5BB" }}>Próximamente: Login Institucional</p>
    </div>
  );
}

function AdminDashboard() {
  const [currentView, setCurrentView] = useState("dashboard");
  const [stats, setStats] = useState({ materias: 0, videos: 0, preguntas: 0 });
  const [loading, setLoading] = useState(true);

  const fetchStats = () => {
    fetch("http://localhost:3001/api/game-data")
      .then(res => res.json())
      .then(data => {
        let materias = data.stations ? data.stations.length : 0;
        let videos = data.stations ? data.stations.filter(s => s.video && s.video !== "").length : 0;
        let preguntas = data.stations ? data.stations.reduce((acc, s) => acc + (s.questions ? s.questions.length : 0), 0) : 0;
        setStats({ materias, videos, preguntas });
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  };

  useEffect(() => {
    if (currentView === "dashboard") {
      fetchStats();
    }
  }, [currentView]);

  return (
    <div className="admin-container">
      {/* Sidebar */}
      <div className="admin-sidebar">
        <div className="admin-brand" style={{ justifyContent: 'center', margin: '20px 0 40px 0' }}>
          <img src="/logo.png" alt="Instituto Juan XXIII" style={{ maxHeight: '110px', maxWidth: '100%' }} />
        </div>

        <ul className="admin-nav-list">
          <li className={`admin-nav-item ${currentView === "dashboard" ? "active" : ""}`} onClick={() => setCurrentView("dashboard")}>
            <LayoutDashboard size={20} />
            Dashboard
          </li>
          <li className={`admin-nav-item ${currentView === "materias" ? "active" : ""}`} onClick={() => setCurrentView("materias")}>
            <BookOpen size={20} />
            Materias
          </li>
          <li className={`admin-nav-item ${currentView === "preguntas" ? "active" : ""}`} onClick={() => setCurrentView("preguntas")}>
            <HelpCircle size={20} />
            Preguntas
          </li>
        </ul>
      </div>

      {/* Main Content */}
      <div className="admin-main">
        {/* Header */}
        <div className="admin-header">
          <div className="admin-top-nav">
            {/* Vacío según instrucciones, mantenemos la estructura por si se necesitan breadcrumbs luego */}
          </div>
          <div className="admin-header-actions">
            <button className="admin-icon-btn"><Bell size={18} /></button>
            <div className="admin-avatar"></div>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="admin-content">
          {currentView === "dashboard" && (
            <>
              <div className="admin-grid-top" style={{ gridTemplateColumns: '1fr' }}>
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                    <h2 className="admin-section-title" style={{ margin: 0 }}>Resumen General</h2>
                  </div>
                  <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap' }}>
                    {/* Card 1 */}
                    <div className="admin-card" style={{ flex: 1, minWidth: '300px' }}>
                      <div className="summary-card">
                        <div className="summary-icon blue">
                          <BookOpen size={24} color="#5051F9" style={{ transform: 'rotate(45deg)' }} />
                        </div>
                        <div className="summary-info">
                          <span>Total Materias</span>
                          <h3>{stats.materias}</h3>
                        </div>
                      </div>
                      <div className="summary-stats">
                        <div className="stat-item">
                          <div className="stat-icon purple"><PlayCircle size={16} /></div>
                          <div className="stat-info">
                            <span>Videos Asignados</span>
                            <h4>{stats.videos}</h4>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Card 2 */}
                    <div className="admin-card" style={{ flex: 1, minWidth: '300px' }}>
                      <div className="summary-card">
                        <div className="summary-icon">
                          <HelpCircle size={24} color="#FF8E53" style={{ transform: 'rotate(45deg)' }} />
                        </div>
                        <div className="summary-info">
                          <span>Total Preguntas</span>
                          <h3>{stats.preguntas}</h3>
                        </div>
                      </div>
                      <div className="summary-stats">
                        <div className="stat-item">
                          <div className="stat-icon orange"><Layers size={16} /></div>
                          <div className="stat-info">
                            <span>Promedio por Materia</span>
                            <h4>{stats.materias ? (stats.preguntas/stats.materias).toFixed(1) : 0}</h4>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="admin-grid-bottom" style={{ gridTemplateColumns: '1fr' }}>
                <div>
                  <h2 className="admin-section-title">Estado del Sistema</h2>
                  <div className="admin-card" style={{ maxWidth: '400px' }}>
                    <div className="mining-item">
                      <div className="mining-icon blue" style={{ background: '#5051F9' }}><Server size={20} /></div>
                      <div className="mining-info">
                        <h4>Servidor Web</h4>
                        <span>En línea</span>
                      </div>
                      <div className="toggle-switch"></div>
                    </div>
                    <div className="mining-item">
                      <div className="mining-icon orange"><Database size={20} /></div>
                      <div className="mining-info">
                        <h4>Base de Datos</h4>
                        <span>Conectada</span>
                      </div>
                      <div className="toggle-switch"></div>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
          
          <div style={{ background: currentView !== 'dashboard' ? '#1B1D27' : 'transparent', borderRadius: '20px', padding: currentView !== 'dashboard' ? '20px' : '0' }}>
             {currentView === "materias" && <MateriasManager />}
             {currentView === "preguntas" && <PreguntasManager />}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<GameView />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/login" element={<AdminLogin />} />
      </Routes>
    </Router>
  );
}
