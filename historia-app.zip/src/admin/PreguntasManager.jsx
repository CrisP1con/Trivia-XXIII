import React, { useState, useEffect } from "react";

export default function PreguntasManager() {
  const [questions, setQuestions] = useState([]);
  const [stations, setStations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingQuestion, setEditingQuestion] = useState(null);

  const [formData, setFormData] = useState({
    station_id: "",
    prompt: "",
    options: ["", "", "", ""],
    answer: 0,
    explanation: ""
  });

  const fetchData = () => {
    setLoading(true);
    Promise.all([
      fetch("http://localhost:3001/api/questions").then(res => res.json()),
      fetch("http://localhost:3001/api/stations").then(res => res.json())
    ]).then(([qData, sData]) => {
      setQuestions(qData);
      setStations(sData);
      if (sData.length > 0 && formData.station_id === "") {
        setFormData(prev => ({ ...prev, station_id: sData[0].id }));
      }
      setLoading(false);
    });
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleOptionChange = (index, value) => {
    const newOptions = [...formData.options];
    newOptions[index] = value;
    setFormData({ ...formData, options: newOptions });
  };

  const handleSave = (e) => {
    e.preventDefault();
    const isEditing = editingQuestion !== null;
    const url = isEditing 
      ? `http://localhost:3001/api/questions/${editingQuestion}`
      : `http://localhost:3001/api/questions`;
    
    fetch(url, {
      method: isEditing ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...formData, answer: parseInt(formData.answer) })
    }).then(res => res.json())
      .then(() => {
        setEditingQuestion(null);
        setFormData({
          station_id: stations.length > 0 ? stations[0].id : "",
          prompt: "",
          options: ["", "", "", ""],
          answer: 0,
          explanation: ""
        });
        fetchData();
      });
  };

  const handleEdit = (q) => {
    setEditingQuestion(q.id);
    setFormData({
      station_id: q.station_id,
      prompt: q.prompt,
      options: q.options.length === 4 ? q.options : ["", "", "", ""],
      answer: q.answer,
      explanation: q.explanation
    });
  };

  const handleDelete = (id) => {
    if (window.confirm("¿Seguro que deseas eliminar esta pregunta?")) {
      fetch(`http://localhost:3001/api/questions/${id}`, {
        method: 'DELETE'
      }).then(() => fetchData());
    }
  };

  const getStationName = (id) => {
    const st = stations.find(s => s.id === id);
    return st ? st.title : "Desconocida";
  };

  const inputStyle = { width: "100%", padding: "10px", margin: "8px 0", borderRadius: "6px", border: "1px solid #444", background: "#222", color: "white" };

  return (
    <div>
      <h1 style={{ marginBottom: "1rem", color: "#6ee7b7" }}>Gestión de Preguntas</h1>
      
      {stations.length === 0 ? (
        <div style={{ background: "#3f0d0d", color: "#fca5a5", padding: "1rem", borderRadius: "8px" }}>
          Debes crear al menos una Materia antes de poder cargar preguntas.
        </div>
      ) : (
        <div style={{ background: "#111", padding: "20px", borderRadius: "12px", marginBottom: "2rem", border: "1px solid #333" }}>
          <h3>{editingQuestion ? "Editar Pregunta" : "Crear Nueva Pregunta"}</h3>
          <form onSubmit={handleSave}>
            <select name="station_id" value={formData.station_id} onChange={handleInputChange} style={inputStyle} required>
              {stations.map(st => <option key={st.id} value={st.id}>{st.title}</option>)}
            </select>
            
            <textarea name="prompt" value={formData.prompt} onChange={handleInputChange} placeholder="¿Cuál es la pregunta?" style={{ ...inputStyle, minHeight: "60px" }} required />
            
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
              {formData.options.map((opt, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: "10px", background: "#222", padding: "10px", borderRadius: "6px", border: formData.answer == i ? "2px solid #10b981" : "2px solid transparent" }}>
                  <input type="radio" name="answer" value={i} checked={formData.answer == i} onChange={handleInputChange} style={{ width: "20px", height: "20px", cursor: "pointer" }} />
                  <input value={opt} onChange={(e) => handleOptionChange(i, e.target.value)} placeholder={`Opción ${String.fromCharCode(65 + i)}`} style={{ flex: 1, padding: "8px", background: "transparent", border: "none", color: "white", outline: "none" }} required />
                </div>
              ))}
            </div>

            <textarea name="explanation" value={formData.explanation} onChange={handleInputChange} placeholder="Explicación o feedback al responder" style={{ ...inputStyle, minHeight: "60px" }} />
            
            <div style={{ marginTop: "10px", display: "flex", gap: "10px" }}>
              <button type="submit" style={{ padding: "10px 20px", background: "#10b981", color: "#000", border: "none", borderRadius: "6px", cursor: "pointer", fontWeight: "bold" }}>
                {editingQuestion ? "Actualizar" : "Guardar Pregunta"}
              </button>
              {editingQuestion && (
                <button type="button" onClick={() => { setEditingQuestion(null); setFormData({ station_id: stations[0].id, prompt: "", options: ["", "", "", ""], answer: 0, explanation: "" }); }} style={{ padding: "10px 20px", background: "#444", color: "white", border: "none", borderRadius: "6px", cursor: "pointer" }}>
                  Cancelar
                </button>
              )}
            </div>
          </form>
        </div>
      )}

      {loading ? <p>Cargando preguntas...</p> : (
        <div style={{ background: "#111", borderRadius: "12px", border: "1px solid #333", overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "#222", textAlign: "left" }}>
                <th style={{ padding: "12px" }}>Materia</th>
                <th style={{ padding: "12px" }}>Pregunta</th>
                <th style={{ padding: "12px" }}>Respuesta</th>
                <th style={{ padding: "12px", width: "150px" }}>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {questions.map(q => (
                <tr key={q.id} style={{ borderTop: "1px solid #333" }}>
                  <td style={{ padding: "12px", fontSize: "0.9rem", color: "#9ca3af" }}>{getStationName(q.station_id)}</td>
                  <td style={{ padding: "12px", fontWeight: "bold" }}>{q.prompt}</td>
                  <td style={{ padding: "12px", color: "#10b981" }}>{q.options[q.answer] || `Opción ${q.answer}`}</td>
                  <td style={{ padding: "12px", display: "flex", gap: "10px" }}>
                    <button onClick={() => handleEdit(q)} style={{ padding: "6px 12px", background: "#1d4ed8", color: "white", border: "none", borderRadius: "4px", cursor: "pointer" }}>Editar</button>
                    <button onClick={() => handleDelete(q.id)} style={{ padding: "6px 12px", background: "transparent", color: "#fca5a5", border: "1px solid #fca5a5", borderRadius: "4px", cursor: "pointer" }}>Borrar</button>
                  </td>
                </tr>
              ))}
              {questions.length === 0 && (
                <tr>
                  <td colSpan="4" style={{ padding: "20px", textAlign: "center", color: "#aaa" }}>No hay preguntas cargadas.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
