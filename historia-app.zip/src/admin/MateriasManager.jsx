import React, { useState, useEffect } from "react";

export default function MateriasManager() {
  const [stations, setStations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingStation, setEditingStation] = useState(null);

  const [formData, setFormData] = useState({
    title: "",
    video: "",
    bridge: "",
    order: 1
  });

  const fetchStations = () => {
    setLoading(true);
    fetch("http://localhost:3001/api/stations")
      .then(res => res.json())
      .then(data => {
        setStations(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchStations();
  }, []);

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSave = (e) => {
    e.preventDefault();
    const isEditing = editingStation !== null;
    const url = isEditing 
      ? `http://localhost:3001/api/stations/${editingStation}`
      : `http://localhost:3001/api/stations`;
    
    fetch(url, {
      method: isEditing ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    }).then(res => res.json())
      .then(() => {
        setEditingStation(null);
        setFormData({ title: "", video: "", bridge: "", order: 1 });
        fetchStations();
      });
  };

  const handleEdit = (station) => {
    setEditingStation(station.id);
    setFormData({
      title: station.title,
      video: station.video,
      bridge: station.bridge,
      order: station.order
    });
  };

  const handleDelete = (id) => {
    if (window.confirm("¿Seguro que deseas eliminar esta materia? Se eliminarán también sus preguntas asociadas.")) {
      fetch(`http://localhost:3001/api/stations/${id}`, {
        method: 'DELETE'
      }).then(() => fetchStations());
    }
  };

  const inputStyle = { width: "100%", padding: "10px", margin: "8px 0", borderRadius: "6px", border: "1px solid #444", background: "#222", color: "white" };

  return (
    <div>
      <h1 style={{ marginBottom: "1rem", color: "#fca5a5" }}>Gestión de Materias</h1>
      
      <div style={{ background: "#111", padding: "20px", borderRadius: "12px", marginBottom: "2rem", border: "1px solid #333" }}>
        <h3>{editingStation ? "Editar Materia" : "Crear Nueva Materia"}</h3>
        <form onSubmit={handleSave}>
          <input name="title" value={formData.title} onChange={handleInputChange} placeholder="Título de la Materia (ej: Historia)" style={inputStyle} required />
          <input name="video" value={formData.video} onChange={handleInputChange} placeholder="Ruta del video (ej: /videos/archivo.mp4)" style={inputStyle} />
          <textarea name="bridge" value={formData.bridge} onChange={handleInputChange} placeholder="Texto puente narrativo" style={{ ...inputStyle, minHeight: "80px" }} />
          <input name="order" type="number" value={formData.order} onChange={handleInputChange} placeholder="Orden numérico" style={inputStyle} required />
          
          <div style={{ marginTop: "10px", display: "flex", gap: "10px" }}>
            <button type="submit" style={{ padding: "10px 20px", background: "#b91c1c", color: "white", border: "none", borderRadius: "6px", cursor: "pointer", fontWeight: "bold" }}>
              {editingStation ? "Actualizar" : "Guardar"}
            </button>
            {editingStation && (
              <button type="button" onClick={() => { setEditingStation(null); setFormData({ title: "", video: "", bridge: "", order: 1 }); }} style={{ padding: "10px 20px", background: "#444", color: "white", border: "none", borderRadius: "6px", cursor: "pointer" }}>
                Cancelar
              </button>
            )}
          </div>
        </form>
      </div>

      {loading ? <p>Cargando materias...</p> : (
        <div style={{ background: "#111", borderRadius: "12px", border: "1px solid #333", overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "#222", textAlign: "left" }}>
                <th style={{ padding: "12px" }}>Orden</th>
                <th style={{ padding: "12px" }}>Título</th>
                <th style={{ padding: "12px" }}>Video</th>
                <th style={{ padding: "12px" }}>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {stations.map(st => (
                <tr key={st.id} style={{ borderTop: "1px solid #333" }}>
                  <td style={{ padding: "12px" }}>{st.order}</td>
                  <td style={{ padding: "12px", fontWeight: "bold" }}>{st.title}</td>
                  <td style={{ padding: "12px", color: "#aaa" }}>{st.video || "Sin video"}</td>
                  <td style={{ padding: "12px", display: "flex", gap: "10px" }}>
                    <button onClick={() => handleEdit(st)} style={{ padding: "6px 12px", background: "#1d4ed8", color: "white", border: "none", borderRadius: "4px", cursor: "pointer" }}>Editar</button>
                    <button onClick={() => handleDelete(st.id)} style={{ padding: "6px 12px", background: "transparent", color: "#fca5a5", border: "1px solid #fca5a5", borderRadius: "4px", cursor: "pointer" }}>Borrar</button>
                  </td>
                </tr>
              ))}
              {stations.length === 0 && (
                <tr>
                  <td colSpan="4" style={{ padding: "20px", textAlign: "center", color: "#aaa" }}>No hay materias cargadas.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
